<?php
//imap_delete($imap, $uid, FT_UID);
//imap_expunge($imap);


	// info messages in folder
	// INBOX.newfolder
	/*
    $status = imap_status($ibox, "{www.fxstar.eu}INBOX", SA_ALL);
    if ($status) {
        echo "your new mailbox '$name1' has the following status:<br />\n";
        echo "Messages:   " . $status->messages    . "<br />\n";
        echo "Recent:     " . $status->recent      . "<br />\n";
        echo "Unseen:     " . $status->unseen      . "<br />\n";
        echo "UIDnext:    " . $status->uidnext     . "<br />\n";
        echo "UIDvalidity:" . $status->uidvalidity . "<br />\n";
    }
	//echo imap_createmailbox($ibox, imap_utf7_encode("{www.fxstar.eu}INBOX"));
	*/
?>